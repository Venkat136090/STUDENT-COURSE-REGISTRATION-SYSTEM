using Microsoft.AspNetCore.Mvc;
using StudentCourseRegistrationSystem.Models;

namespace StudentCourseRegistrationSystem.Controllers
{
    public class StudentController : Controller
    {
        // In-memory storage: data remains available while the application is running.
        private static readonly List<Student> Students = new();
        private static int nextId = 1;

        public IActionResult Index()
        {
            return View(Students);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Student student)
        {
            if (!ModelState.IsValid)
            {
                return View(student);
            }

            student.Id = nextId++;
            Students.Add(student);
            TempData["SuccessMessage"] = "Student registered successfully.";
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Details(int id)
        {
            var student = Students.FirstOrDefault(s => s.Id == id);

            if (student == null)
            {
                return NotFound();
            }

            return View(student);
        }
    }
}
