using Microsoft.AspNetCore.Mvc;

namespace StudentCourseRegistrationSystem.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
