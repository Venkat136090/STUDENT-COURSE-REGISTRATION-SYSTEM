# Student Course Registration System

ASP.NET Core MVC individual activity for .NET Technologies.

## Requirements
- Visual Studio 2022/2026 with the ASP.NET and web development workload
- .NET 8 SDK

## Open and run
1. Extract the ZIP file.
2. Open `StudentCourseRegistrationSystem.csproj` in Visual Studio.
3. Allow Visual Studio to restore dependencies.
4. Select the HTTPS or HTTP launch profile / run the project.
5. The home page opens. Use Register to add a student and Student List to view registrations.

Alternatively, open a terminal in this folder and run:
```bash
dotnet restore
dotnet run
```
Open the localhost URL printed in the terminal.

## Features
- Home page, registration form, student list and student details.
- `Student` model with Required, StringLength, EmailAddress and Range validation.
- GET and POST Create actions, model binding and `ModelState.IsValid`.
- In-memory static list; records are not permanent and reset when the application restarts.

## Important
The assignment says a database is not mandatory. This project uses an in-memory list to meet that requirement. Add your own screenshots after running the application, including one showing validation errors.
